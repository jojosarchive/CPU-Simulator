import java.util.HashMap;
import java.util.LinkedList;

public class Assembler {
    public static String[] assemble(String[] input) {
        return null;
    }

    public static String[] finalOutput(String[] input) {
        return null;
    }
}
