public class Memory {
    public Word32 address= new Word32();
    public Word32 value = new Word32();

    private final Word32[] dram= new Word32[1000];

    public int addressAsInt() {
        return 0;
    }

    public Memory() {
    }

    public void read() {
    }

    public void write() {
    }

    public void load(String[] data) {
    }
}
