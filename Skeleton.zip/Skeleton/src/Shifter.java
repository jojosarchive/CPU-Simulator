public class Shifter {
    public static void LeftShift(Word32 source, int amount, Word32 result) {
    }

    public static void RightShift(Word32 source, int amount, Word32 result) {
    }
}
