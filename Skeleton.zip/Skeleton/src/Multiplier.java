public class Multiplier {
    public static void multiply(Word32 a, Word32 b, Word32 result) {
    }
}
