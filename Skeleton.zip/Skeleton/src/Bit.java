public class Bit {
    public enum boolValues { FALSE, TRUE }
    private boolValues booleanValue;

    public Bit(boolean value) {

        if(value){
            assign(boolValues.TRUE);
        } else if (!value) {
            assign(boolValues.FALSE);
        }
    }

    public boolValues getValue() {
        return this.booleanValue;
    }

    public void assign(boolValues value) {
        this.booleanValue = value;
    }

    public void and(Bit b2, Bit result) {
        // "Bit" references the static method
        Bit.and(this, b2, result);
    }
    /*
    AND
    1  1  1
    0  1  0
    1  0  0
    0  0  0
    */

    public static void and(Bit b1, Bit b2, Bit result) {
        if(b1.booleanValue == boolValues.TRUE && b2.booleanValue == boolValues.TRUE){
            // 1 1
            result.assign(boolValues.TRUE);
        } else if (b1.booleanValue == boolValues.FALSE && b2.booleanValue == boolValues.TRUE) {
            // 0 1
            result.assign(boolValues.FALSE);
        } else if (b1.booleanValue == boolValues.TRUE && b2.booleanValue == boolValues.FALSE){
            // 1 0
            result.assign(boolValues.FALSE);
        } else if (b1.booleanValue == boolValues.FALSE && b2.booleanValue == boolValues.FALSE){
            // 0 0
            result.assign(boolValues.FALSE);
        }
    }

    /*
    OR
    1 1 1
    0 1 1
    1 0 1
    0 0 0
     */

    public void or(Bit b2, Bit result) {
        Bit.or(this, b2, result);
    }

    public static void or(Bit b1, Bit b2, Bit result) {
        if(b1.booleanValue == boolValues.TRUE && b2.booleanValue == boolValues.TRUE){
            // 1 1
            result.booleanValue = boolValues.TRUE;
        }else if(b1.booleanValue == boolValues.FALSE && b2.booleanValue == boolValues.TRUE){
            // 0 1
            result.booleanValue = boolValues.TRUE;
        }else if(b1.booleanValue == boolValues.TRUE && b2.booleanValue == boolValues.FALSE){
            // 1 0
            result.booleanValue = boolValues.TRUE;
        }else if (b1.booleanValue == boolValues.FALSE && b2.booleanValue == boolValues.FALSE) {
            // 0 0
            result.booleanValue = boolValues.FALSE;
        }
    }

    public void xor(Bit b2, Bit result) {
    }

    public static void xor(Bit b1, Bit b2, Bit result) {
    }

    public static void not(Bit b2, Bit result) {
    }

    public void not(Bit result) {
    }

    public String toString() {
        if(booleanValue == boolValues.TRUE){
            return "t";
        }else{
            return "f";
        }

    }
}
