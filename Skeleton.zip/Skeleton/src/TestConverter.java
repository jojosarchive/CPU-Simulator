public class TestConverter {
    public static void fromInt(int value, Word32 result) {
    }

    public static int toInt(Word32 value) {
        return 0;
    }
}