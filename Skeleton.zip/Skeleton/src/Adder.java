public class Adder {
    public static void subtract(Word32 a, Word32 b, Word32 result) {
    }

    public static void add(Word32 a, Word32 b, Word32 result) {
    }
}
